# tests-examples
This project is intended to demostrate the power inside unit testing.

It is divided in two projects: C# && tests.
